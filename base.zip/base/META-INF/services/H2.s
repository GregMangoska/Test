D2.a
